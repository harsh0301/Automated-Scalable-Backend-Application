# # WebApp


This is the Webapp for Cloud Assignment

# To create the initialization
npm init -y

# To install Express
npm install --save express

# To use import statement module in index.js add "type":"module"

# Have installed Nodemon so that server restart after every changes
npm install --save-dev nodemon
add in package.json -- in scripts -- "start":"nodemon index.js"

# To start the Web
npm start

# To check the working
curl -v http://localhost:8080/healthz

added the test file npm test to run

Installed bcrypt moment basic-auth files for updation and validation.

check packer and orm and ami build from main

.

